
class ping():
    def __init__(self,URL):
        self.URL
    
  
    def ping(slef):
        print(self.URL)    

        