import smktest.check

__all__=["smktest"]