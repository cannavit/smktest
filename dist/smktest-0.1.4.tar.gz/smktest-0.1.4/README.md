# Example Package

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

This library is created to include test cases through the SMKTEST library in an easy and safe way in projects that have automation in CICD environments.